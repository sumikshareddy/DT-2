package com.niit.scart.DAO;

import java.io.IOException;
import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;

public interface CartDAO {

	public List<Cart> viewAllCart();
	public Cart getCartById(int cartid);
	public void deleteCart(int cid);
	public void addCart(Cart cart);
	Cart validate(int cartId) throws IOException;
	void update(Cart cart);
}
	
