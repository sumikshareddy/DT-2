package com.niit.scart.service;

import com.niit.scart.model.UserOrder;


public interface OrderService 
{
    void addOrder(UserOrder order);
    double getOrderGrandTotal(int cartId);
}
