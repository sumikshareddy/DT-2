package com.niit.scart.DAO;

import com.niit.scart.model.UserOrder;


public interface OrderDAO {

    void addOrder(UserOrder userOrder);

}
