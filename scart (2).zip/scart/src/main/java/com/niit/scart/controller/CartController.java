package com.niit.scart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;
import com.niit.scart.service.ICartService;
import com.niit.scart.service.IProductService;
import com.niit.scart.service.IUserService;


@Controller
public class CartController {
	                             
	@Autowired(required=true)
	ICartService iCartService;
	
	@Autowired(required=true)
	IProductService iProductService;
	
	@Autowired(required=true)
	IUserService iUserService;
	
	/*@RequestMapping(value = {"cart"})
	public ModelAndView cart() {
		System.out.println("cart");
		return new ModelAndView("cart");
	}
*/
	@RequestMapping(value = { "Product/cart" })
	public ModelAndView cart(HttpServletRequest request)
	{
		String pid = request.getParameter("p");
		System.out.println("cart");
		return new ModelAndView("cart", "command", new Cart()).addObject("cart",iCartService.viewAllCart()).addObject("products",iProductService.viewAllProducts());
	}
	
	@RequestMapping(value = { "Product/storecart" })
	public ModelAndView addcart(HttpServletRequest request, @ModelAttribute("scart") Product p,BindingResult result) {
		System.out.println("Store Cart");
		String pid = request.getParameter("p");
		Cart c=new Cart();
		c.setProduct(iProductService.editProduct(Integer.parseInt(pid)));
		c.setQuantity(1);
		System.out.print("adding to cart "+iUserService.getUser());
		c.setUser(iUserService.getUser());
		iCartService.addToCart(c);
		return new ModelAndView("cart", "cartItem",c);//.addObject("cart", iProductService.viewAllProducts());
	
	}
}
	/*int tcid=0;

	@RequestMapping(value = { "storecart" })
	public ModelAndView storeProduct(HttpServletRequest request,ModelMap model, @ModelAttribute("cart")Cart c,BindingResult result) {
				int pid=Integer.parseInt(request.getParameter("cart"));
				iCartService.viewAllCart(pid);
		System.out.println("Store cart "+pid);
		return new ModelAndView("cart", "command", new Cart()).addObject("cart", iCartService.viewAllCart()).addObject("Product",iProductService.viewAllProducts());
		
					if(result.hasErrors()){
				return new ModelAndView("cart", "command", new Cart()).addObject("cart", iCartService.viewAllCart()).addObject("Product",iProductService.viewAllProducts());
			}
		else{
			iProductService.viewAllProducts();
			return new ModelAndView("cart", "command", new Cart()).addObject("cart", iCartService.viewAllCart()).addObject("Product",iProductService.viewAllProducts());
	}
			for(int i=0;i<Cart.size();i++){
				if(Product==Cart.class)
			}
			for (int i=0; i<cart.size(); i++) {
	            if(Product.getPid()==Cart.getPid()){
	            	System.out.println("Inside for loop");
	                CartItem cartItem = cartItems.get(i);
	                cartItem.setQuantity(cartItem.getQuantity()+1);
	                cartItem.setTotalPrice(item.getPrice()*cartItem.getQuantity());
	                cartItemService.addCartItem(cartItem);

	                return;
	            }
	        }

	 
	
			@RequestMapping(value = { "Cart/delete" })
		public ModelAndView delete(HttpServletRequest request) 
		{
		
			String cartid=request.getParameter("c");
			iCartService.deleteCart(Integer.parseInt(cartid));
			System.out.println("Delete Category");
			return new ModelAndView("cart", "command", new Cart()).addObject("cart",iCartService.viewAllCart());
		}
    @RequestMapping(value = {"cart"})
	public ModelAndView cart() {
		System.out.println("cart");
		return new ModelAndView("cart");
	}
*/
	
