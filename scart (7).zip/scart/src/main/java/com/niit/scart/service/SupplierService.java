package com.niit.scart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.scart.DAO.SupplierDAO;
import com.niit.scart.model.Supplier;

@Service("SupplierService")
public class SupplierService implements ISupplierService{

	@Autowired(required=true)
	public SupplierDAO sd;
	
	public void addSupplier(Supplier s)
	{
		sd.addUser(s);
	}
	public Supplier verify(Supplier s){
		
		return sd.verify(s);
	}
}
