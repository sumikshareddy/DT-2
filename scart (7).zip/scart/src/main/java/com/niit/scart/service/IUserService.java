package com.niit.scart.service;

import com.niit.scart.model.User;

public interface IUserService
{
	void addUser(User u);
    User verify(User u);
	public User getUser();
	Object setUser(Object object);
}
