package com.peer.DAO;

import com.peer.model.Blog;
import com.peer.model.Comment;

import antlr.debug.Event;

public interface CommentDAO {
	public void addcomment(Comment e);
	public void deletecomment(int id);
	public void updatecomment(Comment e);

}
