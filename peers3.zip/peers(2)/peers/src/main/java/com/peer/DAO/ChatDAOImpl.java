package com.peer.DAO;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.peer.model.Chat;

@Repository("ChatDAO")
public class ChatDAOImpl implements ChatDAO{

    private Chat chat;
    
    @Autowired 
    private SessionFactory sf;
    
    @Transactional(propagation=Propagation.SUPPORTS)
	public void createchat(Chat chat) {
		// TODO Auto-generated method stub
		
	}
	
}
