package com.peer.DAO;

import com.peer.model.Chat;

public interface ChatDAO {
	public void createchat(Chat chat);
}
