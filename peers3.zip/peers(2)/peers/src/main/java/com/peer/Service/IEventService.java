package com.peer.Service;

import com.peer.model.Event;


public interface IEventService {
	public void addevent(Event e);
	public void deleteevent(int id);
	public void updateevent(Event e);
}
