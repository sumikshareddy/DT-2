package com.peer.Controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.peer.Service.IBlogService;
import com.peer.Service.ICommentService;
import com.peer.Service.IEventService;
import com.peer.Service.IForumService;
import com.peer.Service.IUserService;
import com.peer.model.Blog;
import com.peer.model.Comment;
import com.peer.model.Event;
import com.peer.model.Forum;
import com.peer.model.User;

@Controller
public class HomeController {
	@Autowired
	IUserService iUserService;
	@Autowired
	IEventService iEventService;
	@Autowired
	IForumService iForumService;
	@Autowired
	IBlogService iBlogService;
	@Autowired
	ICommentService iCommentService;
		
	@RequestMapping(value=  { "/" , "home"})
	public ModelAndView login() {
		System.out.println("home");
		return new ModelAndView("home");
	}
	@RequestMapping(value=  { "blog"})
	public ModelAndView blog() {
		System.out.println("blog");
		return new ModelAndView("blog","command",new Blog());
	}
	@RequestMapping(value = "store3", method=RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request,@Valid @ModelAttribute("peer") Blog b,BindingResult result) {
		System.out.println("addblog");
		
		iBlogService.addblog(b);
		ModelAndView mv=new ModelAndView("store3");
		System.out.println("store4");
		if(result.hasErrors()){

			mv=new ModelAndView("blog", "command", new Blog());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iBlogService.addblog(b);
		mv=new ModelAndView("blog", "command", new Blog());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}
	@RequestMapping(value=  { "viewblog"})
	public ModelAndView viewblog() {
		System.out.println("viewblog");
		String jsonData="";
		ObjectMapper mapper=new ObjectMapper();
		try {
			jsonData=mapper.writeValueAsString(iBlogService.viewBlog());
			System.out.println(jsonData);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("viewblog","command",new Blog()).addObject("blogs", jsonData);
	}

	@RequestMapping(value=  { "comment"})
	public ModelAndView comment() {
		System.out.println("comment");
		return new ModelAndView("comment","command",new Comment());
	}
	@RequestMapping(value=  { "addblog"})
	public ModelAndView addblog() {
		System.out.println("addblog");
		return new ModelAndView("addblog","command",new Comment());
	}
	@RequestMapping(value = "store7", method=RequestMethod.POST)
	public ModelAndView blog(HttpServletRequest request,@Valid @ModelAttribute("peer") Blog b,BindingResult result) {
		System.out.println("addblog");
		b.setDate(new Date());
		iBlogService.addblog(b);
		ModelAndView mv=new ModelAndView("store3");
		System.out.println("store8");
		if(result.hasErrors()){

			mv=new ModelAndView("addtoblog", "command", new Comment());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iBlogService.addblog(b);
		mv=new ModelAndView("comment", "command", new Comment());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}



	@RequestMapping(value=  { "forum"})
	public ModelAndView forum() {
		System.out.println("forum");
		return new ModelAndView("forum","command",new Forum());
	}
	@RequestMapping(value = "store2", method=RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request,@Valid @ModelAttribute("peer") Forum f,BindingResult result) {
		System.out.println("addforum");
		
		iForumService.addquestion(f);
		ModelAndView mv=new ModelAndView("store1");
		System.out.println("store2");
		if(result.hasErrors()){

			mv=new ModelAndView("forum", "command", new Forum());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iForumService.addquestion(f);
		mv=new ModelAndView("event", "command", new Event());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}


	
		
		//@modelattribute An annotated method parameter can be mapped to an attribute in a model .

	
	@RequestMapping(value = { "login" })
	public ModelAndView Login() {
		System.out.println("Login");
		return new ModelAndView("login","command",new User()).addObject("login", true);
	}
	@RequestMapping(value = { "event" })
	public ModelAndView event() {
		System.out.println("event");
		return new ModelAndView("event","command",new Event());
		
	}
	@RequestMapping(value = "store1", method=RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request,@Valid @ModelAttribute("peer") Event e,BindingResult result) {
		System.out.println("addevent");
		e.setDate(new Date());
		iEventService.addevent(e);
		ModelAndView mv=new ModelAndView("store1");
		System.out.println("store1");
		if(result.hasErrors()){

			mv=new ModelAndView("event", "command", new Event());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iEventService.addevent(e);
		mv=new ModelAndView("event", "command", new Event());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}

	
	
	@RequestMapping(value = { "signup" })
	public ModelAndView signup() {
		System.out.println("signup");
		return new ModelAndView("signup","command",new User()).addObject("signup", true);
	}
	
	
	@RequestMapping(value = "store", method=RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request,@Valid @ModelAttribute("peer") User u,BindingResult result) {
		System.out.println("Register");
		u.setDate(new Date());
		iUserService.adduser(u);
		ModelAndView mv=new ModelAndView("store");
		System.out.println("store");
		if(result.hasErrors()){

			mv=new ModelAndView("signup", "command", new User());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iUserService.adduser(u);
		mv=new ModelAndView("login", "command", new User());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}
	
	//@modelattribute An annotated method parameter can be mapped to an attribute in a model .
	
	@RequestMapping(value = { "LoginUser" })
	public ModelAndView Login(HttpServletRequest request,@ModelAttribute("peer") User u,BindingResult result) {
		System.out.println("Login");
		User user=iUserService.verifyuser(u);
		ModelAndView mv=new ModelAndView("home");
		
		return mv;
	}
	
}
