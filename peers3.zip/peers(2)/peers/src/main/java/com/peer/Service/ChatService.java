package com.peer.Service;

import org.springframework.stereotype.Service;

import com.peer.model.Chat;

@Service("ChatService")
public class ChatService implements IChatService{

	public void createchat(Chat chat) {
		// TODO Auto-generated method stub
		
	}

}
