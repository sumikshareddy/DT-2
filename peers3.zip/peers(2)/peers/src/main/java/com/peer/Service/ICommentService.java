package com.peer.Service;

import com.peer.model.Blog;
import com.peer.model.Comment;

import antlr.debug.Event;

public interface ICommentService {
	public void addcomment(Comment e);
	public void deletecomment(int id);
	public void updatecomment(Comment e);

}
