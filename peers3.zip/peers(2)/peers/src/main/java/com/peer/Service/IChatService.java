package com.peer.Service;

import com.peer.model.Chat;

public interface IChatService {
	public void createchat(Chat chat);
}
