package com.niit.scart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.web.bind.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;
import com.niit.scart.model.User;
import com.niit.scart.service.CartService;
import com.niit.scart.service.ICartService;
import com.niit.scart.service.IProductService;
import com.niit.scart.service.IUserService;
import com.niit.scart.service.ProductService;

@Controller
public class CartController {
	                             
	@Autowired(required=true)
	ICartService iCartService;
	
	@Autowired(required=true)
	IProductService iProductService;
	
	@Autowired(required=true)
	IUserService iUserService;
	
		
	@RequestMapping(value = { "Product/cart" })
	public ModelAndView cart(HttpServletRequest request)
	{
		
		String pid = request.getParameter("p");
		System.out.println("cart");
		return new ModelAndView("cart","p",iProductService.editProduct(Integer.parseInt(pid))).addObject("cart",iCartService.viewAllCart());
	}
	
	@RequestMapping(value = { "storecart" })
	public ModelAndView addcart(HttpServletRequest request) {
		System.out.println("Store Cart");
		String pid = request.getParameter("p");
		Cart c=new Cart();
		c.setProduct(iProductService.editProduct(Integer.parseInt(pid)));
		c.setQuantity(1);
		System.out.print("adding to cart "+iUserService.getUser());
		c.setUser(iUserService.getUser());
		iCartService.addCart(c);
		return new ModelAndView("cart", "cartItem",c).addObject("cart", iCartService.viewAllCart());
	}
	
	@RequestMapping(value = { "Cart/delete" })
	public ModelAndView delete(HttpServletRequest request) {

		String pid = request.getParameter("c");
		iCartService.deleteCart(Integer.parseInt(pid));
		System.out.println("Delete cart");
		return new ModelAndView("addproduct", "command", new Cart()).addObject("cart",
				iCartService.viewAllCart());
	}

	@RequestMapping(value = { "product/buy" })
	public ModelAndView buy() {
		System.out.println("buy");
		return new ModelAndView("buy");
	}
	
	@RequestMapping(value = { "index" })
	public ModelAndView home(HttpServletRequest request) 
	{
		System.out.println("continue shopping");
		return new ModelAndView("index");
	}
}