package com.niit.scart.DAO;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;

public interface CartDAO {

	public List<Cart> viewAllCart();
	public void deleteCart(int cid);
	public void addCart(Cart cart);
}
	
