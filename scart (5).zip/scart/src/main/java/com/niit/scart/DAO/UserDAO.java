package com.niit.scart.DAO;

import com.niit.scart.model.User;

public interface UserDAO {
	public void addUser(User u);
	public User verify(User u);
	public User getUser();
}
