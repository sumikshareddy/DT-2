package com.niit.scart.service;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;
import com.niit.scart.model.User;

public interface ICartService {
	
	public List<Cart> viewAllCart();
	public void deleteCart(int cartid);
	public void addCart(Cart c);

}
