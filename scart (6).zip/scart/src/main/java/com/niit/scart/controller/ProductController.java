package com.niit.scart.controller;

import java.io.BufferedOutputStream;

import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Category;
import com.niit.scart.model.Product;
import com.niit.scart.model.User;
import com.niit.scart.service.ICartService;
import com.niit.scart.service.ICategoryService;
import com.niit.scart.service.IProductService;
import com.niit.scart.util.Util;
//@Controller annotation just tells the container that this bean is a designated controller class
@Controller
public class ProductController {
	//By default,whereever spring containers finds @autowire anotation,it autowires bean byType. You can use @Autowire annotation on setter method to get rid of <property> tag in XML configuration file.
	@Autowired(required = true)
	IProductService iProductService;
	
	@Autowired(required = true)
	ICartService iCartService;

	@Autowired(required = true)
	ICategoryService iCategoryService;

	int tpid = 0;
	
	//@RequestMapping annotation is used to map a particular HTTP request method 
	@RequestMapping(value = { "/addproduct" })
	public ModelAndView addProduct(@ModelAttribute("cart") Product p,BindingResult result) {
		System.out.println("add Product");
		
		return new ModelAndView("addproduct", "command", new Product()).addObject("product", iProductService.viewAllProducts()).addObject("Category",iCategoryService.viewAllCategory()).addObject("stat", "Add Product");
	}
	@RequestMapping(value = { "products" })
	public ModelAndView products(HttpServletRequest request) {
		int cid=Integer.parseInt(request.getParameter("c"));
		Category c=iCategoryService.editCategory(cid);
		System.out.println("category "+cid);
		return new ModelAndView("products").addObject("products",iProductService.viewAllProducts(c));
	}
	
	@RequestMapping(value = { "productdetails" })
	public ModelAndView productdetails(HttpServletRequest request,Product p) {
		
		String pid = request.getParameter("p");
		System.out.println("productdetails");
		return new ModelAndView("productdetails","p",iProductService.editProduct(Integer.parseInt(pid))).addObject("product",p);
	
}
	
	
 
	@RequestMapping(value = { "storeproduct" })
	public ModelAndView storeProduct(HttpServletRequest request, @RequestParam("image") MultipartFile file,ModelMap model, @ModelAttribute("cart") Product p,BindingResult result) {
		
		int cid=Integer.parseInt(request.getParameter("category"));
		
		System.out.println("Store Product "+cid);
			p.setCategory(iCategoryService.editCategory(cid));
			String name=Util.removeComma(p.getPname());
			p.setPname(name);
			for(ObjectError o:result.getAllErrors()){
				System.out.print(o.getDefaultMessage());
			}
			iProductService.addProduct(p);
			String fileName = null,error="";
	    	if (!file.isEmpty()) {
	            try {
	                fileName = file.getOriginalFilename();
	                byte[] bytes = file.getBytes();
	                BufferedOutputStream buffStream = new BufferedOutputStream(new FileOutputStream(new File("C:\\Users\\sumiksha reddy\\shopkhoj\\scart\\src\\main\\webapp\\resources\\project\\" + fileName)));
	                buffStream.write(bytes);
	                buffStream.close();
	                error= "You have successfully uploaded " + fileName;
	            } catch (Exception e) {
	            	error="You failed to upload " + fileName + ": " + e.getMessage();
	            }
	        } else {
	        	error="Unable to upload. File is empty.";
	        }
	    	File oldName = new File("C:\\Users\\sumiksha reddy\\shopkhoj\\scart\\src\\main\\webapp\\resources\\project\\" + fileName);
	        File newName = new File("C:\\Users\\sumiksha reddy\\shopkhoj\\scart\\src\\main\\webapp\\resources\\project\\" + p.getPname()+fileName.substring(fileName.indexOf(".")));
	        System.out.println(p.getPid());
	        if(oldName.renameTo(newName)) {
	           error=p.getPname()+" Profile Upload Successfully !";
	        }
		
		return new ModelAndView("addproduct", "command", new Product()).addObject("products", iProductService.viewAllProducts()).addObject("Category",iCategoryService.viewAllCategory()).addObject("stat", "Add Product");
	}

	@RequestMapping(value = { "/Product/storeproduct" })
	public ModelAndView updateProduct(HttpServletRequest request, @ModelAttribute("cart") Product p,
			BindingResult result) {
		System.out.println("Store Product");
		p.setPid(tpid);
		iProductService.updateProduct(p);
		return new ModelAndView("addproduct", "command", new Product()).addObject("addproduct", iProductService.viewAllProducts());
	}

	@RequestMapping(value = { "Product/delete" })
	public ModelAndView delete(HttpServletRequest request) {

		String pid = request.getParameter("p");
		iProductService.deleteProduct(Integer.parseInt(pid));
		System.out.println("Delete Product");
		return new ModelAndView("addproduct", "command", new Product()).addObject("cart",
				iProductService.viewAllProducts());
	}

	@RequestMapping(value = { "/Product/edit" })
	public ModelAndView edit(HttpServletRequest request) {
		System.out.println("Edit Product");
		String pid = request.getParameter("p");
		tpid = iProductService.editProduct(Integer.parseInt(pid)).getPid();
		System.out.println(tpid);
		return new ModelAndView("addproduct", "command", iProductService.editProduct(Integer.parseInt(pid))).addObject("products", iProductService.viewAllProducts()).addObject("Category",iCategoryService.viewAllCategory()).addObject("stat", "Edit Product");
		
	}
}

		
	

	