package com.niit.scart.DAO;

import com.niit.scart.model.Supplier;

public interface SupplierDAO {

	void addUser(Supplier s);

	Supplier verify(Supplier s);

}
