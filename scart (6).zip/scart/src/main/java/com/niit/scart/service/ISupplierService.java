package com.niit.scart.service;

import com.niit.scart.model.Supplier;

public interface ISupplierService 
{
	public void addSupplier(Supplier s);
	Supplier verify(Supplier s);
}
