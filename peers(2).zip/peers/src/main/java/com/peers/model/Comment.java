	package com.peers.model;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.ManyToOne;
	import javax.persistence.OneToMany;
	import javax.persistence.OneToOne;
	import javax.validation.constraints.NotNull;
	import javax.validation.constraints.Size;

	import org.codehaus.jackson.annotate.JsonIgnore;
	import org.hibernate.validator.constraints.Email;
	import org.springframework.stereotype.Component;


	@Entity
	public class Comment {
		
		@ManyToOne
		@JoinColumn(name="User",nullable=false)
		private User user;
		
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer cid;


	@NotNull
	@Size(min = 3, max = 14, message="firstname must have atleat 3 letter")
	@Column
	private String cname;


	@Column
	@NotNull
	@Size(min = 3, max = 14, message="address must have atleast 6 letter")
	private String cdesc;


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Integer getCid() {
		return cid;
	}


	public void setCid(Integer cid) {
		this.cid = cid;
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}


	public String getCdesc() {
		return cdesc;
	}


	public void setCdesc(String cdesc) {
		this.cdesc = cdesc;
	}
	}

	