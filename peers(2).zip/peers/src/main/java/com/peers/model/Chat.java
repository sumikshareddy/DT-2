package com.peers.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;


@Entity
public class Chat {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private Integer chatid;


@NotNull
@Size(min = 3, max = 14, message="firstname must have atleat 3 letter")
@Column
private String message;


@Column
@NotNull
@Size(min = 3, max = 14, message="address must have atleast 6 letter")
private String fromuser;

@Column
@NotNull
@Size(min = 3, max = 14, message="address must have atleast 6 letter")
private String touser;

public Integer getChatid() {
	return chatid;
}

public void setChatid(Integer chatid) {
	this.chatid = chatid;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

public String getFromuser() {
	return fromuser;
}

public void setFromuser(String fromuser) {
	this.fromuser = fromuser;
}

public String getTouser() {
	return touser;
}

public void setTouser(String touser) {
	this.touser = touser;
}

}