package com.peers.model;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.ManyToOne;
	import javax.persistence.OneToMany;
	import javax.persistence.OneToOne;
	import javax.validation.constraints.NotNull;
	import javax.validation.constraints.Size;

	import org.codehaus.jackson.annotate.JsonIgnore;
	import org.hibernate.validator.constraints.Email;
	import org.springframework.stereotype.Component;


	@Entity
	public class Event {
		
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer eid;


	@NotNull
	@Size(min = 3, max = 14, message="firstname must have atleat 3 letter")
	@Column
	private String ename;


	@Column
	@NotNull
	@Size(min = 3, max = 14, message="address must have atleast 6 letter")
	private String edesc;


	public Integer getEid() {
		return eid;
	}


	public void setEid(Integer eid) {
		this.eid = eid;
	}


	public String getEname() {
		return ename;
	}


	public void setEname(String ename) {
		this.ename = ename;
	}


	public String getEdesc() {
		return edesc;
	}


	public void setEdesc(String edesc) {
		this.edesc = edesc;
	}
	}


	