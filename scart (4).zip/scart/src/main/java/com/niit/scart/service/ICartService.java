package com.niit.scart.service;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;

public interface ICartService {
	
	public List<Cart> viewAllCart();
	public List<Cart> viewAllCart(Product pid);
	public void deleteCart(int cartid);
	public Cart storeCart(int pid);
	public void addToCart(Cart cart);
	public Cart editCart(int cartid);

	
	/*public void addCart(Cart cart);
	public void removeCart(Cart cart);
*/	}

