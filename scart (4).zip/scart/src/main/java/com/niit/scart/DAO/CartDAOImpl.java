package com.niit.scart.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;


@Repository("CartDAO")
@Transactional
public class CartDAOImpl implements CartDAO{
	@Autowired
	private SessionFactory sf;

	/*public void addCart(Cart cart) {
		
			System.out.println("inside crat");
			System.out.println(cart.getCartid());
			Session s = sf.getCurrentSession();
	        try
	        {
	          Transaction tx=s.beginTransaction();	
	        s.saveOrUpdate(cart);
	        tx.commit();
	        System.out.println("After session:"+cart.getCartid());
	        }
	        catch(Exception e)
	        {
	        	System.out.println("exception:"+e);
	        }
	        System.out.println("after save or update");
	    }



	public void removeCart(Cart cart) {

		 Session s = sf.getCurrentSession();
	      Transaction tx=s.beginTransaction();
	       
	        System.out.println("In Remove Cart Item");
	        System.out.println(cart.getCartid());
	        try {
	        	 s.delete(cart);
			} catch (Exception e) {
				System.out.println("Exception:"+e);
			}
	       tx.commit();
	 
	        System.out.println("after remove cart item");
	        s.flush();
	    }

*/
	@Transactional(propagation = Propagation.SUPPORTS)
	public List<Cart> viewAllCart() {
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Cart> l1 = (List<Cart>) sf.getCurrentSession().createCriteria(Cart.class).list();
		t.commit();
		return l1;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional(propagation = Propagation.SUPPORTS)
	public List<Cart> viewAllCart(Product p)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		Criteria c=sf.getCurrentSession().createCriteria(Cart.class);
		c.add(Restrictions.eq("product", p));
		List<Cart> l1 = (List<Cart>) c.list();
		t.commit();
		return l1;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS)
	public void deleteCart(int cartid)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
        Cart c1=(Cart) s.load(Cart.class,cartid);
        s.delete(c1);
		t.commit();
	}

	@Transactional(propagation = Propagation.SUPPORTS)
	public List<Cart> viewAllCart(int pid)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		Criteria c=sf.getCurrentSession().createCriteria(Cart.class);
		c.add(Restrictions.eq("product", pid));
		List<Cart> l1 = (List<Cart>) c.list();
		t.commit();
		return l1;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS)
	public Cart storeCart(int pid)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		Cart c1=(Cart)s.get(Cart.class,pid);
		System.out.println(c1.getCartid());
		t.commit();
		return c1;
	}
	public void addToCart(Cart cart){
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.save(cart);
		t.commit();
	}
	

	





}
