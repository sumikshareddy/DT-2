package com.niit.scart.DAO;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;

public interface CartDAO {

	
	public List<Cart> viewAllCart();
	public void deleteCart(int cid);
	public List<Cart> viewAllCart(Product pid);
	public Cart storeCart(int pid);
	public void addToCart(Cart cart);
	
	/*public void addCart(Cart cart);

	public void removeCart(Cart cart);
*/
	}
	
