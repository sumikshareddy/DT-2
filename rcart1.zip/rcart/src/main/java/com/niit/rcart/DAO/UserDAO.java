package com.niit.rcart.DAO;

import com.niit.rcart.model.User;

public interface UserDAO 
{
	public void addUser(User u);
	public User verify(User u);
	public User getUser();
	public Object setUser(Object object);
}
