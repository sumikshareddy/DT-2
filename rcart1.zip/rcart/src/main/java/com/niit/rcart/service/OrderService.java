package com.niit.rcart.service;

import com.niit.rcart.model.UserOrder;


public interface OrderService 
{
    void addOrder(UserOrder order);
    double getOrderGrandTotal(int cartId);
}
