package com.niit.rcart.DAO;

import java.io.IOException;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.rcart.model.Cart;
import com.niit.rcart.model.Product;


@Repository("CartDAO")
public class CartDAOImpl implements CartDAO{
	
	@Autowired
	private SessionFactory sf;

	@Transactional(propagation = Propagation.SUPPORTS)
	public List<Cart> viewAllCart() 
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Cart> l1 = (List<Cart>) sf.getCurrentSession().createCriteria(Cart.class).list();
		t.commit();
		return l1;
	}
	
	@Transactional(propagation = Propagation.SUPPORTS)
	public void deleteCart(int cartid)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		Cart c=(Cart) s.load(Cart.class, cartid);
		System.out.println(c.getCartid());
        Cart c1=(Cart) s.load(Cart.class,cartid);
        System.out.println(c1.getCartid());
        s.delete(c1);
		t.commit();
	}

	public void addCart(Cart cart)
	{
		Session s = sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.save(cart);
		t.commit();
	}

	public Cart validate(int cartId) throws IOException {
		Cart cart=getCartById(cartId);
        System.out.println("cart id:"+cart.getCartid());
        if(cart==null||cart.getCartid()==0) {
            throw new IOException(cartId+"");
        }
        update(cart);
        return cart;
    }

	public Cart getCartById(int cartid) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Cart cart) {
		// TODO Auto-generated method stub
		
	}

	


		
	}

