package com.niit.rcart.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.rcart.model.Product;
import com.niit.rcart.model.Supplier;

@Repository("SupplierDAO")
public class SupplierDAOImpl implements SupplierDAO {

	@Autowired
	private SessionFactory sf;
	
   @Transactional(propagation=Propagation.SUPPORTS)
   public void addSupplier(Supplier s) {
	   Session s1=sf.getCurrentSession();
		Transaction t=s1.beginTransaction();
			s1.saveOrUpdate(s);
			t.commit();
	}
	
   @Transactional(propagation=Propagation.SUPPORTS)
   public List<Supplier> viewAllSupplier() {
	   Session s1=sf.getCurrentSession();
	   Transaction t=s1.beginTransaction();
	   Criteria c=sf.getCurrentSession().createCriteria(Supplier.class);
	   List<Supplier> l1 = (List<Supplier>) c.list();
		t.commit();
	    return l1;
}
    @Transactional(propagation=Propagation.SUPPORTS)
    public void deleteSupplier(int sid) {
    	Session s=sf.getCurrentSession();
    	Transaction t=s.beginTransaction();
    	Supplier s1=(Supplier) s.load(Supplier.class,sid);
    	t.commit();
 
}
    @Transactional(propagation=Propagation.SUPPORTS)
    public void updateSupplier(Supplier s) {
    	Session s1=sf.getCurrentSession();
    	Transaction t=s1.beginTransaction();
    	System.out.println(s.getSid());
		System.out.println(s.getSname());
		System.out.println(s.getSaddress());
		s1.update(s);
		t.commit();
 
}
     @Transactional(propagation=Propagation.SUPPORTS)
     public Supplier editSupplier(int sid) {

 		Session s = sf.getCurrentSession();
 		Transaction t = s.beginTransaction();
 		Supplier s1=(Supplier)s.get(Supplier.class,sid);
 		System.out.println(s1.getSid());
 		t.commit();
 		return s1 ;
 	}
	
	
}









