package com.niit.rcart.service;
/*package com.niit.scart.service;


import com.niit.scart.DAO.OrderDAO;
import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;
import com.niit.scart.model.UserOrder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class IOrderService implements OrderService{

    @Autowired
    private OrderDAO orderDao;

    @Autowired
    private CartService cartService;

    public void addOrder(UserOrder userOrder) {
    	orderDao.addOrder(userOrder);
    }

    public double getOrderGrandTotal(int cartId) {
        double grandTotal=0;
        Cart c = cartService.getCartById(cartId);
        List<Cart> c1 = c1.getCartid();

        for (Cart item : c1) {
            grandTotal+=Product.getPrice();
        }

        return grandTotal;
    }
}
*/