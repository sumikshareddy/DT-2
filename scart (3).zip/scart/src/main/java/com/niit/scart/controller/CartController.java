package com.niit.scart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;
import com.niit.scart.service.ICartService;
import com.niit.scart.service.IProductService;
import com.niit.scart.service.IUserService;

@Controller
public class CartController {
	                             
	@Autowired(required=true)
	ICartService iCartService;
	
	@Autowired(required=true)
	IProductService iProductService;
	
	@Autowired(required=true)
	IUserService iUserService;
	
		
	@RequestMapping(value = { "Product/cart" })
	public ModelAndView cart(HttpServletRequest request)
	{
		String pid = request.getParameter("p");
		System.out.println("cart");
		return new ModelAndView("cart", "command", new Cart()).addObject("cart",iCartService.viewAllCart()).addObject("products",iProductService.viewAllProducts());
	}
	
	@RequestMapping(value = { "Product/storecart" })
	public ModelAndView addcart(HttpServletRequest request, @ModelAttribute("eshop") Product p,BindingResult result) {
		System.out.println("Store Cart");
		String pid = request.getParameter("p");
		Cart c=new Cart();
		c.setProduct(iProductService.editProduct(Integer.parseInt(pid)));
		c.setQuantity(1);
		System.out.print("adding to cart "+iUserService.getUser());
		c.setUser(iUserService.getUser());
		iCartService.addToCart(c);
		return new ModelAndView("cart", "cartItem",c);//.addObject("cart", iProductService.viewAllProducts());
	}
	
	@RequestMapping(value = { "Cart/delete" })
	public ModelAndView delete(HttpServletRequest request) {

		String pid = request.getParameter("p");
		iCartService.deleteCart(Integer.parseInt(pid));
		System.out.println("Delete Product");
		return new ModelAndView("cart", "command", new Cart()).addObject("cart",iCartService.viewAllCart());
	}

	@RequestMapping(value = { "Product/buy" })
	public ModelAndView buy() {
		System.out.println("buy");
		return new ModelAndView("buy");
	}
	
	/*@RequestMapping(value = { "confirm" })
	public ModelAndView confirm() {
		System.out.println("confirm");
		return new ModelAndView("confirm");
	}*/
	
	@RequestMapping(value = { "home" })
	public ModelAndView home(HttpServletRequest request) {
		System.out.println("continue shopping");
		return new ModelAndView("index");
	}
}