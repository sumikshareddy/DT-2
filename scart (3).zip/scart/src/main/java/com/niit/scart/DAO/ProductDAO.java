package com.niit.scart.DAO;

import java.util.List;

import com.niit.scart.model.Category;
import com.niit.scart.model.Product;

public interface ProductDAO {

	void addProduct(Product p);
	public List<Product> viewAllProducts(Category c);
	public List<Product> viewAllProducts();
	public void deleteProduct(int pid);
	public Product editProduct(int pid);
	public void updateProduct(Product p);
	Product cart(int pid);
	
}
	
