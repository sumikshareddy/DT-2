package com.niit.scart.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.scart.model.Supplier;

@Repository("SupplierDAO")
public class SupplierDAOImpl implements SupplierDAO {

	@Autowired
	private SessionFactory sf;
	
   @Transactional(propagation=Propagation.SUPPORTS)
	public void addUser(Supplier s) {
		Session s1=sf.getCurrentSession();
	Transaction t=s1.beginTransaction();
		s1.saveOrUpdate(s);
		t.commit();
	}

public Supplier verify(Supplier s) {
	// TODO Auto-generated method stub
	return null;
}



}
