package com.niit.scart.DAO;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Product;

public interface CartDAO {

	
	public List<Cart> viewAllCart();
	public List<Cart> viewAllCart(Product p);
	public void deleteCart(int cid);
	
}
	
