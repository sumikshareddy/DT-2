package com.niit.scart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CartController {
	@RequestMapping(value = "cart")
	public ModelAndView cart() {
		System.out.println("cart");
		return new ModelAndView("cart");
	}
}



/*import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.niit.scart.model.Product;

@Controller
@RequestMapping("cart")
@SessionAttributes({"cart"})
public class CartController {
 
  *//**
   * Creates a new cart if one does not exist in session.
   *//*
  @RequestMapping(method = RequestMethod.GET)
  public String get(Model model) {
    if(!model.containsAttribute("cart")) {
      model.addAttribute("cart", new ArrayList<Product>());
    }
    return "cart";
  }
   */
  /**
   * The shopping cart (list of products) is stored in session. Simply inject it using
   * method argument
   *//*
  @RequestMapping(value = "addProduct", method = RequestMethod.POST)
  public String addProduct(@ModelAttribute Product product,
      @ModelAttribute("cart") List<Product> cart) {
    cart.add(product);
    return "redirect:/";
  
 
}
}
*/
	/*	import java.util.List;
	
	import javax.servlet.http.HttpServletRequest;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.servlet.ModelAndView;
	
	import com.niit.scart.model.Cart;
	import com.niit.scart.model.Product;
	import com.niit.scart.service.CartService;
	import com.niit.scart.service.ICartService;
	import com.niit.scart.service.IProductService;

@Controller
public class CartController {
	
	@Autowired(required = true)
	IProductService iProductService;
	
	@Autowired(required = true)
	ICartService iCartService;
	
	
	@RequestMapping(value = { "/cart" })
	public ModelAndView Cart() {
		System.out.println("cart");
		return new ModelAndView("cart", "command", new Cart()).addObject("cart", iCartService.viewAllCart()).addObject("Product",iProductService.viewAllProducts());
	
		List<Cart> cart;
		for (int i=0; i<cart.size(); i++) {
        if(Product.getPid()==cart.get(i).getCartid()){
        	System.out.println("Inside for loop");
          
            cart.setQuantity( cart.getQuantity()+1);
            Product product;
			cart.setTotalPrice(product.getPrice()*cart.getQuantity());
           

            return null ;
        }
	}
	@RequestMapping(value = {"Product/remove"})
	public ModelAndView delete(HttpServletRequest request) {

		String pid = request.getParameter("p");
		
		iCartService.deleteCart(Integer.parseInt(pid));
		System.out.println("remove Product");
		return new ModelAndView("cart", "command", new Cart()).addObject("cart",
				iCartService.viewAllCart());
	}
	
*/
	