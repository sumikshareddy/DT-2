/*package com.niit.scart.DAO;

import com.niit.scart.model.Cart;
import com.niit.scart.model.CartItem;


public interface CartItemDAO {

    void addCartItem(CartItem cartItem);

    void removeCartItem(CartItem cartItem);

    void removeAllCartItems(Cart cart);

    CartItem getCartItemByItemId (int itemId);

}
*/