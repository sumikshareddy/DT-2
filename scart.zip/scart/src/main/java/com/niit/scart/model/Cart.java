package com.niit.scart.model;

import java.io.Serializable;

public class Cart implements Serializable {
	 
	  private static final long serialVersionUID = 1L;
	   
	  private String name;
	  private double price;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

/*@Entity
@Table(name = "Cart")
@Component
public class Cart {

	@ManyToOne
	@JoinColumn(name="Product",nullable = false)
	private Product product;
	@Id
	public Integer cartid;
	
	@Column
	private String cartName;
	@Column
	private Integer quantity;
	@Column
	private double totalPrice;
	


	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Integer getCartid() {
		return cartid;
	}

	public void setCartid(Integer cartid) {
		this.cartid = cartid;
	}

	public String getCartName() {
		return cartName;
	}

	public void setCartName(String cartName) {
		this.cartName = cartName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	
}
*/