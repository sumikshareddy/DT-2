package com.niit.scart.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Category;
import com.niit.scart.model.User;
import com.niit.scart.service.ICategoryService;
import com.niit.scart.service.IProductService;


@Controller
public class HomeController {	
	
	@Autowired
	ICategoryService iCategoryService;
	
	@Autowired
	IProductService iProductService;
	
	@RequestMapping(value = { "/" , "home"})
	public ModelAndView index() {
		System.out.println("home");
		return new ModelAndView("index").addObject("Categorys",iCategoryService.viewAllCategory());
	}
	@RequestMapping(value = { "welcome"})
	public ModelAndView welcome() {
		System.out.println("welcome to home");
		return new ModelAndView("welcome");
	}
	@RequestMapping(value = { "about" })
	public ModelAndView about() {
		System.out.println("about");
		return new ModelAndView("aboutUs");
	}
	
	@RequestMapping(value = { "contact" })
	public ModelAndView contact() {
		System.out.println("contact");
		return new ModelAndView("contactUs");
	}
	
	@RequestMapping(value = { "boys" })
	public ModelAndView boys() {
		System.out.println("boys");
		return new ModelAndView("boys");
	}
	
	@RequestMapping(value = { "girls" })
	public ModelAndView girls() {
		System.out.println("girls");
		return new ModelAndView("girls");
	}
	
	@RequestMapping(value = { "products" })
	public ModelAndView women(HttpServletRequest request) {
		int cid=Integer.parseInt(request.getParameter("c"));
		Category c=iCategoryService.editCategory(cid);
		System.out.println("category "+cid);
		return new ModelAndView("products").addObject("products", iProductService.viewAllProducts(c));
	}
	
	@RequestMapping(value = { "men" })
	public ModelAndView men() {
		System.out.println("men");
		return new ModelAndView("men");
	}
	
	
	
	@RequestMapping(value = { "productdetails" })
	public ModelAndView productdetails() {
		System.out.println("productdetails");
		return new ModelAndView("productdetails");
	}
	
	@RequestMapping(value = { "login" })
	public ModelAndView Login() {
		System.out.println("Login");
		return new ModelAndView("home","command",new User()).addObject("login", true);
	}
	
	@RequestMapping(value = { "register" })
	public ModelAndView register() {
		System.out.println("register");
		return new ModelAndView("home","command",new User()).addObject("register", true);
	}
	@RequestMapping(value = { "logout" })
	public ModelAndView logout() {
		System.out.println("logout");
		return new ModelAndView("home","command",new User()).addObject("logout", true);
	}
	
	@RequestMapping(value = { "buy" })
	public ModelAndView buy() {
		System.out.println("buy");
		return new ModelAndView("buy");
	}
	@RequestMapping(value = { "confirm" })
	public ModelAndView confirm() {
		System.out.println("confirm");
		return new ModelAndView("confirm");
	}
}
