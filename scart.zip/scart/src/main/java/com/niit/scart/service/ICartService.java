package com.niit.scart.service;

import java.util.List;

import com.niit.scart.model.Cart;
import com.niit.scart.model.Category;
import com.niit.scart.model.Product;

public interface ICartService {
	
	public List<Cart> viewAllCart();
	public List<Cart> viewAllCart(Product p);

	public void deleteCart(int cartid);
	}
