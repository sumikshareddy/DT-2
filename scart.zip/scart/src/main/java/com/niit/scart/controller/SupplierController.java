package com.niit.scart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.scart.model.Supplier;
import com.niit.scart.model.User;
import com.niit.scart.service.ISupplierService;

@Controller
public class SupplierController {

	/* @Autowired(required=true)
	 ISupplierService iSupplierService;
	 
	 @RequestMapping(value = { "store" })
		public ModelAndView register(HttpServletRequest request,@ModelAttribute("cart") Supplier s,BindingResult result) {
			System.out.println("Register");
			iSupplierService.addSupplier(s);		
			return new ModelAndView("home","command",new Supplier()).addObject("login", true);
		}
	 
	 @RequestMapping(value = { "LoginUser" })
		public ModelAndView login(HttpServletRequest request,@ModelAttribute("cart") Supplier s,BindingResult result) {
			System.out.println("LoginUser");
			Supplier supplier=iSupplierService.verify(s);
			iSupplierService.addSupplier(s);		
			return new ModelAndView("home","welcome",supplier);
		}*/
}
