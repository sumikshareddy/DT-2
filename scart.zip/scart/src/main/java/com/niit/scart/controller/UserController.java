package com.niit.scart.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.niit.scart.model.User;
import com.niit.scart.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService iUserService;
		
	@RequestMapping(value = "store", method=RequestMethod.POST)
	public ModelAndView register(/*HttpServletRequest request,*/@Valid @ModelAttribute("cart") User u,BindingResult result) {
		System.out.println("Register");
		//iUserService.addUser(u);
		ModelAndView mv=new ModelAndView("store");
		if(result.hasErrors()){
			mv=new ModelAndView("register", "command", new User());
					mv.addObject("errors", result.getAllErrors());
					for(ObjectError s:result.getAllErrors()){
						System.out.println(s);
					}
		}
		else{
			iUserService.addUser(u);
		mv=new ModelAndView("home", "command", new User());
		}
		return mv;
		//return new ModelAndView("home","command",new User()).addObject("login", true);
	}
	
	@RequestMapping(value = { "LoginUser" })
	public ModelAndView Login(HttpServletRequest request,@ModelAttribute("cart") User u,BindingResult result) {
		System.out.println("Login");
		User user=iUserService.verify(u);
		
		ModelAndView mv=new ModelAndView("home","Welcome",user);
		if(user.getRole()==1)
		{
			System.out.println(user.getRole());
			mv.addObject("userRole","isAdmin");
		}
		else if(user.getRole()==2)
		{
			System.out.println(user.getRole());
			mv.addObject("userRole","isSupplier");
		}
		
		return mv;
	}
	}