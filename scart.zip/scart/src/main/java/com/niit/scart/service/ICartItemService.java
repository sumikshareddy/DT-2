/*package com.niit.scart.service;

import com.niit.scart.DAO.CartItemDAO;
import com.niit.scart.model.Cart;
import com.niit.scart.model.CartItem;
import com.niit.scart.service.CartItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class ICartItemService implements CartItemService{

    @Autowired
    private CartItemDAO cartItemDAO;

    public void addCartItem(CartItem cartItem) {
        cartItemDAO.addCartItem(cartItem);
    }

    public void removeCartItem(CartItem cartItem) {
    	
        cartItemDAO.removeCartItem(cartItem);
    }

    public void removeAllCartItems(Cart cart){
    	System.out.println("In Remove Cart item service");
        cartItemDAO.removeAllCartItems(cart);
    }

    public CartItem getCartItemByItemId (int itemId) {
        return cartItemDAO.getCartItemByItemId(itemId);
    }
}
*/